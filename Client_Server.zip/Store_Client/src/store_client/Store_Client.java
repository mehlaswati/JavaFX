/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package store_client;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import store_server.ProductInfo;

/**
 *
 * @author VarunChaudhary
 */
public class Store_Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner sc = new Scanner(System.in).useDelimiter("\\n");
        System.out.println((char)27 + "[35m" + " --- WELCOME TO THE SUPERHERO FIGUREINE STORE --- ");
       
        System.out.println("HELLO! User Please Enter Your Name, To Get Started !");
        String user = sc.next();
        
        try(FileWriter fw = new FileWriter("/Users/varunchaudhary/NetBeansProjects/Store_Client/usernameFromClient.txt", true);
    BufferedWriter bw = new BufferedWriter(fw);
    PrintWriter out = new PrintWriter(bw))
    {
        out.println(user );

    } catch (IOException e) {
    //exception handling left as an exercise for the reade
    }
      
        
        
        String toySearch = "";
        while(true){
        System.out.println();
//        System.out.println((char)27 + "[35m" + "Please select from the list of operations");
//        System.out.println((char)27 + "[35m" + " Enter \"1\" to Search for a figureine");
//        System.out.println((char)27 + "[35m" + " Enter \"2\" to buy the fugureine");
//        System.out.println((char)27 + "[35m" + " ENter \"3\" to exit");
        
        System.out.println("Please select from the list of operations");
        System.out.println("Enter \"1\" to Search for a figureine");
        System.out.println("Enter \"2\" to buy the fugureine");
        System.out.println("ENter \"3\" to exit");
        String option = sc.next();
        
        
        if(option.equals("1")){
            System.out.println((char)27 + "[35m" + "ENter the toy you want to search from DC and Marvel Comics . . .");
            
            toySearch = sc.next();

            System.out.println(" Searching for "+ toySearch + " . . .");
//            System.out.println();
            store_server.ProductInfo prod_info = new store_server.ProductInfo();
            prod_info = searchTheSuperHeroAndPowerInfo(toySearch);
//            System.out.println(prod_info);
//            System.out.println(prod_info.getName());
            
        if(prod_info.getName() == null){
            System.out.println((char)27 + "[31m" + "SORRY NO STOCK FOR THIS FIGUREINE");
            
            break;
        }else{
       System.out.println((char)27 + "[32m" + "Wow!, You are a "+ prod_info.getName() + " fan !!");
       System.out.println((char)27 + "[32m" + prod_info.getName() + " is a character from " + prod_info.getToyComics() + " Comics");
       System.out.println((char)27 + "[32m" + "And Is of Race : Human with " + prod_info.getEyeColor() + " eyes and "+ prod_info.getHairColor() + " hair");


        if (Integer.parseInt(prod_info.getQuantity()) == 0){
            System.out.println((char)27 + "[31m" + "Sorry No figurines remaining in stock. Please come back again later :(");

        }else{
            System.out.println((char)27 + "[35m" + prod_info.getQuantity() + " figurines remaining in the stock. Buy Fast!");

            
        }}
        
        }else if(option.equals("2")){

            System.out.println("Do you want to purchase? (Y/N)");
        if(sc.next().toLowerCase().equals("y")){
            String result = purchaseToy(toySearch);
            System.out.println((char)27 +"[35m" + result);
            
        }
            
            
        }else{
            System.out.println((char)27 + "[35m" + "Please visit again");
            System.out.println("Program exiting . . .");

            break;
        }}
        
    }
    
    public static void writeUsername(String Username) throws IOException
{

     
    BufferedWriter writer = new BufferedWriter(new FileWriter("/Users/varunchaudhary/NetBeansProjects/Store_Client/usernameFromClient.txt",true));
    writer.write(Username);
    writer.close();
}
    
    

    private static ProductInfo searchTheSuperHeroAndPowerInfo(java.lang.String toyName) {
        store_server.ToyWS_Service service = new store_server.ToyWS_Service();
        store_server.ToyWS port = service.getToyWSPort();
        return port.searchTheSuperHeroAndPowerInfo(toyName);
    }

    private static String purchaseToy(java.lang.String name) {

        store_server.ToyWS_Service service = new store_server.ToyWS_Service();
        store_server.ToyWS port = service.getToyWSPort();
        return port.purchaseToy(name);
    }
    
    
    
    
        
        
    }
    

