/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Store_Server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import org.w3c.dom.NodeList;

/**
 *
 * @author VarunChaudhary
 */
public class Server_MessageHandler implements SOAPHandler<SOAPMessageContext> {
    
    public boolean handleMessage(SOAPMessageContext messageContext) {
    String outProperty = SOAPMessageContext.MESSAGE_OUTBOUND_PROPERTY; boolean outgoing = (Boolean)messageContext.get(outProperty);
    SOAPMessage msg = messageContext.getMessage();
    String username="";
    
        SOAPBody body;
        Boolean toBereturned = false;
        String currentInputOperation = "";
        Boolean operationSeqFlag = false;
        
        
        
        try {
            body = msg.getSOAPBody();
            currentInputOperation = body.getChildNodes().item(0).getLocalName();
        } catch (SOAPException ex) {
            Logger.getLogger(Server_MessageHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    try
    {
    if (outgoing)
    msg.writeTo(new FileOutputStream("/Users/varunchaudhary/NetBeansProjects/Store_Client/responseMessage.txt"));
    else {
        SOAPHeader header=msg.getSOAPHeader(); 
        Iterator it=header.examineAllHeaderElements(); 
        while(it.hasNext()){
            
        SOAPHeaderElement e=(SOAPHeaderElement) 
           it.next(); 
        NodeList nl=e.getElementsByTagName("wsse:Username"); 
        for (int i=0;i<nl.getLength();i++){
        username+=nl.item(i).getTextContent(); }
        }
        FileOutputStream f=new FileOutputStream("/Users/varunchaudhary/NetBeansProjects/Store_Client/serv_username.txt"); 
        byte data[]=username.getBytes();
        f.write(data);
        

       
        if(currentInputOperation.equalsIgnoreCase("searchTheSuperHeroAndPowerInfo")){
            msg.writeTo(new FileOutputStream("/Users/varunchaudhary/NetBeansProjects/Store_Client/inputMessage.txt"));

            updateUsername("add");}
            else{


                    if(checkInDB() == false){

                    toBereturned = false;
                    System.out.println("Wrong operation");
                    throw new SOAPException("Wrong operation");
                    
                            }
                    else{
                        //delete user
                        updateUsername("deleter");
                    }
       
        }
        
                
} }
catch(IOException e){ System.out.println("IO Error!!!!"); throw new RuntimeException(e);
}
catch(SOAPException e) {
System.out.println("SOAP IO Error!!!!");
throw new RuntimeException(e);
//e.getMessage();
}
return true; }
    
    public Set<QName> getHeaders() {
        return Collections.EMPTY_SET;
    }
    
    public boolean handleFault(SOAPMessageContext messageContext) {
        return true;
    }
    
    public void close(MessageContext context) {
    }
    

    
    
    private void updateUsername(String operation) {
        Connection conn = null;
        Statement stmt = null;
        Scanner fileScanner = null;
        String retrivedUsername = "";
        //get username
//        File file = new File("/Users/varunchaudhary/NetBeansProjects/Store_Client/serv_username.txt");
//        try {
//            fileScanner = new Scanner(file);
//
//            while (fileScanner.hasNextLine()) {
//                retrivedUsername = fileScanner.nextLine();
//            }
//        } catch (FileNotFoundException ex) {
//            Logger.getLogger(Server_MessageHandler.class.getName()).log(Level.SEVERE, null, ex);
//        }
        String usrnm = "";
        try{
        BufferedReader input = new BufferedReader(new FileReader("/Users/varunchaudhary/NetBeansProjects/Store_Client/serv_username.txt"));
        
        String line;

        while ((line = input.readLine()) != null) { 
            usrnm = line;
        
        }}catch(IOException fne){
            System.out.println(fne.getMessage());
        }
        
        System.out.println("gotUserName");
        System.out.println(usrnm);
        try {
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("[SERVER] Connecting to a selected database...");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/WebService_SuperToys", "root", "Welcome@123");
            System.out.println("[SERVER] Connected database successfully...");
            System.out.println("[SERVER]: Creating statement...");
            stmt = conn.createStatement();
            String sql = "";
            if(operation.equals("add")){
             sql = "insert into userlog values ('" + String.valueOf(usrnm) + "')";}
            else{
                 sql = "delete from userlog where name = '" + String.valueOf(usrnm) + "'";
            }
            stmt.executeUpdate(sql);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //finally block used to close resources
            try {
                if (stmt != null) {
                    conn.close();
                }
            } catch (SQLException se) {
            }// do nothing
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }//end finally try
        }
    }
    
    public boolean checkInDB(){
        Connection myConn = null;
        Statement myStmt = null;
        ResultSet myRs = null;
        Boolean userfound = false;
        Scanner fileScanner = null;
        
        String retrivedUsername = "";
        //get username
        File file = new File("/Users/varunchaudhary/NetBeansProjects/Store_Client/serv_username.txt");
        try {
            fileScanner = new Scanner(file);

            while (fileScanner.hasNextLine()) {
                retrivedUsername = fileScanner.nextLine();
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Server_MessageHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        try {
            
            Class.forName("com.mysql.jdbc.Driver");
            
            // 1. Get a connection to database
            myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/WebService_SuperToys", "root", "Welcome@123");

            // 2. Create a statement
            myStmt = myConn.createStatement();

            // 3. Execute SQL query
            myRs = myStmt.executeQuery("select * from userlog where name = '" + String.valueOf(retrivedUsername) + "'");
//            myStmt.executeUpdate("Insert into UserSession(name) values('" + Username + "'");
            
            if (myRs.next()) {
                //account exists
                myRs.close();
//                System.out.println("Account exists!");
                return true;

            } else {
                //account does not exist
                myRs.close();
//                System.out.println("Accout does not exist!");
                return false;
            }

            
            
        
        
    }catch (Exception exc) {
            System.out.println("Some error in the system. Look at the exception below");
            System.out.println(exc);
        } finally {
            try{
            if (myRs != null) {
                myRs.close();
            }}
            catch(Exception e){
                e.printStackTrace();
            }
            
            try{
            if (myStmt != null) {
                myStmt.close();
            }}catch(Exception e){
            e.printStackTrace();
        }
            try{
            if (myConn != null) {
                myConn.close();
            }}catch(Exception e){
                e.printStackTrace();
            }
        }
       return false; 
    }
    
}
