/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Store_Server;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.HandlerChain;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author Swati
 */
@WebService(serviceName = "toyWS")
@HandlerChain(file = "toyWS_handler.xml")
public class toyWS {

    
    public static final String USER = "root";
    public static final String PASS = "Welcome@123";
    
    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "searchTheSuperHeroAndPowerInfo")
    public Product_Info getInfo(@WebParam(name = "toy_name") String toy_name) {
             
        Store_Server.Product_Info p = new Store_Server.Product_Info();
        Connection myConn = null;
        Statement myStmt = null;
        ResultSet myRs = null;
        
        try {
            
            Class.forName("com.mysql.jdbc.Driver");
            
            // 1. Get a connection to database
            myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/WebService_SuperToys", USER, PASS);

            // 2. Create a statement
            myStmt = myConn.createStatement();

            // 3. Execute SQL query
            myRs = myStmt.executeQuery("select * from heroes_information where name = '" + String.valueOf(toy_name) + "'");
            System.out.println(toy_name);
            // 4. Process the result set
            while (myRs.next()) {
                String id = String.valueOf(myRs.getInt("id"));
                String name = myRs.getString("name");
                String toy_Comics = myRs.getString("Publisher");
                String quantity = myRs.getString("NumberOf_figurines_InStock");
                String race = myRs.getString("Race");
                String eye_c = myRs.getString("Eye color");
                String hair_c = myRs.getString("Hair color");
                
                p.setId(id);
                p.setName(name);
                p.setToy_Comics(toy_Comics);
                p.setQuantity(quantity);
                p.setRace(race);
                p.seteye_color(eye_c);
                p.sethair_color(hair_c);
                
           
            }
            
            } catch (Exception exc) {
            System.out.println(exc);
        } finally {
            try{
            if (myRs != null) {
                myRs.close();
            }}
            catch(Exception e){
                e.printStackTrace();
            }
            
            try{
            if (myStmt != null) {
                myStmt.close();
            }}catch(Exception e){
            e.printStackTrace();
        }
            try{
            if (myConn != null) {
                myConn.close();
            }}catch(Exception e){
                e.printStackTrace();
            }
        }
    
        return p;
        
    }
    
    @WebMethod(operationName = "purchaseToy")
    public String purchaseToy(@WebParam(name = "name") String toy_name) {
        Store_Server.Product_Info p = new Store_Server.Product_Info();
        
        System.out.println("USERNAME FROM PURCHASE TOY WEBSERVICE CALL");
        
        Connection myConn = null;
        Statement myStmt = null;
        ResultSet myRs = null;
        try {
            
            Class.forName("com.mysql.jdbc.Driver");
            
            // 1. Get a connection to database
            myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/WebService_SuperToys", USER, PASS);

            // 2. Create a statement
            myStmt = myConn.createStatement();
            
            myRs = myStmt.executeQuery("select * from heroes_information where name = '" + String.valueOf(toy_name) + "'");
            System.out.println(toy_name);
            // 4. Process the result set
            String quantity = "";
            while (myRs.next()) {
                
                quantity = myRs.getString("NumberOf_figurines_InStock");
      
            }
            
            if(Integer.parseInt(quantity) == 0){
                return "OUT OF STOCK, PLEASE COME AGAIN LATER";
            }else{
            
            
            
            
            String query = "Update WebService_SuperToys.heroes_information set NumberOf_figurines_InStock = NumberOf_figurines_InStock - 1 where name = '" + String.valueOf(toy_name) + "'";
            
            PreparedStatement preparedStmt = myConn.prepareStatement(query);
            // 3. Execute SQL query
            preparedStmt.executeUpdate();
            
            }
            
            
            

            
            
        
        
    }
        catch (Exception exc) {
            System.out.println("Some error in the system. Look at the exception below");
            System.out.println(exc);
        } finally {
            try{
            if (myRs != null) {
                myRs.close();
            }}
            catch(Exception e){
                e.printStackTrace();
            }
            
            try{
            if (myStmt != null) {
                myStmt.close();
            }}catch(Exception e){
            e.printStackTrace();
        }
            try{
            if (myConn != null) {
                myConn.close();
            }}catch(Exception e){
                e.printStackTrace();
            }
        }
        return " --- Purchase Complete --- ";
    
}
    

    
}
