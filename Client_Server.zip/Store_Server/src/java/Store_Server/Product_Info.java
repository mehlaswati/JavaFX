/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Store_Server;

/**
 *
 * @author Swati
 */
public class Product_Info {
    String toyName;
    String toy_ID;
    String toy_Comics;
    String current_Quantity;
    String superhero_Race;
    String hair_color;
    String eye_color;
    
    public void setName(String a) {
        toyName = a;
    }

    public String getName() {
        return toyName;
    }

    public void setId(String b) {
        toy_ID = b;
    }

    public String getId() {
        return toy_ID;
    }

    public void setToy_Comics(String c) {
        toy_Comics = c;
    }

    public String getToy_Comics() {
        return toy_Comics;
    }
    
    public void setQuantity(String d) {
        current_Quantity = d;
    }

    public String getQuantity() {
        return current_Quantity;
    }
    public void setRace(String e) {
        superhero_Race = e;
    }

    public String getRace() {
        return superhero_Race;
    }
    public void seteye_color(String e) {
        eye_color = e;
    }

    public String geteye_color() {
        return eye_color;
    }
    public void sethair_color(String e) {
        hair_color = e;
    }

    public String gethair_color() {
        return hair_color;
    }
    
    

}
